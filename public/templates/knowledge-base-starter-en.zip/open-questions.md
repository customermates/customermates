# Example unanswered questions

Illustrative only. Owner: Example operations lead. Reviewed: 2026-10-29.

If the approved source does not answer a question, record the question and ask the responsible person. Absence of a term is not permission to promise it. A source-linked draft must show which page supports each statement.

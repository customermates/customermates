# Example operating guide

Illustrative company only. Owner: Example operations lead. Reviewed: 2026-10-29.

Before customer work, read the handover procedure and the scope reference. Use the customer record as the source for its current status. Do not invent a response time, refund promise or commercial term. Prepare an internal next step for a human to review. These rules guide an external client; they are not server-enforced MCP approvals.

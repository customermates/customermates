# Fiktiver Betriebsleitfaden

Nur ein fiktives Unternehmen. Verantwortlich: Example operations lead. Geprüft: 29.10.2026.

Lesen Sie vor der Kundenarbeit das Übergabeverfahren und die Referenz zum Leistungsumfang. Den aktuellen Status entnehmen Sie dem Kundendatensatz. Erfinden Sie keine Antwortfrist, Erstattungszusage oder Vertragsbedingung. Bereiten Sie einen internen nächsten Schritt zur Prüfung vor. Diese Regeln leiten einen externen Client an; sie sind keine serverseitig erzwungene MCP-Freigabe.
